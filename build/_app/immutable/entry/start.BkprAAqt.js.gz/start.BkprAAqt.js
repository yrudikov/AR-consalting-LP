import{l as s,a}from"../chunks/BdDplePf.js";export{s as load_css,a as start};
//# sourceMappingURL=start.BkprAAqt.js.map
